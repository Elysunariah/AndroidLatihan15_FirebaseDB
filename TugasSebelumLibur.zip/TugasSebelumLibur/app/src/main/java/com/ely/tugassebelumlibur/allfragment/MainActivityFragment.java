package com.ely.tugassebelumlibur.allfragment;

import android.support.v7.app.AppCompatActivity;

public class MainActivityFragment extends AppCompatActivity {

    
}
