package com.ely.tugassebelumlibur;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

public class AfterClass extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.afterklick);
        ImageView imgView = findViewById(R.id.imgview);
        TextView tv_negara = findViewById(R.id.buku);

        String buku = "";
        Bundle b = getIntent().getExtras();
        if (b != null) {
            buku = b.getString("buku");
        }

        if (buku.equals("btg")) {
            imgView.setImageResource(R.drawable.bintang);
        } else if (buku.equals("cdd")) {
            imgView.setImageResource(R.drawable.cdd);
        } else if (buku.equals("lsk")) {
            imgView.setImageResource(R.drawable.laskar);
        } else if (buku.equals("plg")) {
            imgView.setImageResource(R.drawable.plg);
        } else if (buku.equals("hjn")) {
            imgView.setImageResource(R.drawable.rain);
        } else {
            imgView.setImageResource(R.drawable.cdd);
            tv_negara.setText("lorem ipsum");
        }
    }
}
