package com.ely.tugassebelumlibur.allviews;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;


import com.ely.tugassebelumlibur.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class TambahData extends AppCompatActivity {

    EditText et_judul, et_penulis;
    Button btn;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tambahdata);
        et_judul = findViewById(R.id.et_judul);
        et_penulis = findViewById(R.id.et_penulis);
        btn = findViewById(R.id.et_btn);




        }
    }

