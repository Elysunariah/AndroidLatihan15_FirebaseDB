package com.ely.tugassebelumlibur;

public class Const {
    public final static String BASE_URL = "http://ngopidevteam.com/simplesample/";
    public final static String TAMPIL_DATA = "showdata.php";
    public final static String DETAIL_DATA = "detaildata.php";
}
