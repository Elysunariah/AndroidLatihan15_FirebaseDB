package com.ely.tugassebelumlibur;

import android.content.Context;
import android.support.v7.widget.GridLayoutManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class ImageAdapters extends BaseAdapter {
    public Context ctx;

    public Integer[] gambars = {
            R.drawable.bintang, R.drawable.cdd, R.drawable.laskar,
            R.drawable.plg, R.drawable.rain
    };

    public ImageAdapters (Context ctx) { this.ctx = ctx; }

    @Override
    public int getCount() { return gambars.length; }

    @Override
    public Object getItem(int i) { return gambars[i]; }

    @Override
    public long getItemId(int i) { return 0; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imgView = new ImageView(ctx);
        imgView.setImageResource(gambars[position]);
        imgView.setScaleType(ImageView.ScaleType.CENTER.CENTER_CROP);
        imgView.setLayoutParams(new GridLayoutManager.LayoutParams(300, 300));
        return imgView;
    }
}
