package com.ely.tugassebelumlibur;

        import android.content.Context;
        import android.content.Intent;
        import android.os.Bundle;
        import android.os.Handler;
        import android.support.annotation.Nullable;
        import android.support.v7.app.AppCompatActivity;

        import com.ely.tugassebelumlibur.allviews.TampilData;

public class SplashScreen extends AppCompatActivity {
    private Context ctx;
    private static final int lamawaktu = 3000;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splashscreen);
        ctx = this;

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(ctx, MainActivity.class);
                startActivity(i);
                finish();
            }

        },lamawaktu);



    }

}
