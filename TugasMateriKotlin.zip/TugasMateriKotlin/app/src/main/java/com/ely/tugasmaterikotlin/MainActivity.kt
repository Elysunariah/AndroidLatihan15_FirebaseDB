package com.ely.tugasmaterikotlin

        import android.support.v7.app.AppCompatActivity
                import android.os.Bundle
                import android.util.Log
        import android.view.View
        import android.widget.Adapter
                import android.widget.ArrayAdapter
                import android.widget.TextView
                import android.widget.Toast
                import kotlinx.android.synthetic.main.login.*
        import kotlin.math.sign

class MainActivity : AppCompatActivity() {

            var a = "contoh"//secara default di deklarasi sebagai String
            var aa: String = "contoh"
            lateinit var aaa: String

            val b = "contoh"
            val bb: String = "contoh"
            val bbb: String = ""

            val nilai = 10

            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
                setContentView(R.layout.activity_main)

                val text = """
            #data pertama
            #data kedua
            #data ketiga
        """.trimMargin("#")

                Log.d("TAG_SAMPLE", text)

                for (a: Int in 1..10) { //dalam java => for(int a = 1; a <= 10; a++)
                    Log.d("TAG_SAMPLE", "a = " + a)

                    Log.d("TAG_SAMPLE", "a = " + a)
                    Log.e("TAG_SAMPLE", "a = " + a)
                    Log.i("TAG_SAMPLE", "a = " + a)

                    Konstanta.setterGetterBeda

                }

            }
        }