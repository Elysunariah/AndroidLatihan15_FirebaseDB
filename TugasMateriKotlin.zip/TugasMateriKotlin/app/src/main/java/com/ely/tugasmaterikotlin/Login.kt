package com.ely.tugasmaterikotlin

import android.os.Bundle
import android.os.PersistableBundle
import android.support.v7.app.AppCompatActivity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.login.*

class Login : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        // get reference
        var tv_nama= findViewById(R.id.tv_nama) as EditText
        var tv_jenis= findViewById(R.id.tv_jenis) as EditText
        var btn = findViewById(R.id.btn) as Button

        btn.setOnClickListener {
            //

            tv_nama.setText("")
            tv_jenis.setText("")
        }

        btn.setOnClickListener {
            val username = tv_nama.text
            val jenis_kelamin = tv_jenis.text
            Toast.makeText(this, "username tidak boleh kosong", Toast.LENGTH_SHORT).show()
        }
        tv_nama.setOnClickListener {
            Toast.makeText(this, "elly", Toast.LENGTH_SHORT).show()
        }
        // Create an ArrayAdapter
        val adapter= ArrayAdapter.createFromResource(this,
            R.array.jenis_kelamin, android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter



    }


}







